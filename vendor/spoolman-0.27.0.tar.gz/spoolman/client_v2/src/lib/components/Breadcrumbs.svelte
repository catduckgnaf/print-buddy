<script lang="ts">
	/* eslint-disable svelte/no-navigation-without-resolve --
	   Generic link component: `href` arrives already resolved against the deploy base
	   path (the params.ts helpers that produce it call resolve()), so resolving it
	   again here would double-apply the base path. */
	import ChevronRight from '@lucide/svelte/icons/chevron-right';
	// Inspector breadcrumb trail. The last item is the current entity (rendered
	// static); earlier items with an `href` are navigable links. A `muted` crumb
	// stands in for a level that doesn't exist (e.g. a filament with no
	// manufacturer) — there's nothing to navigate to, so it reads as a note.
	export interface Crumb {
		label: string;
		href?: string;
		muted?: boolean;
	}
	let { items }: { items: Crumb[] } = $props();
</script>

<div class="crumbs">
	{#each items as c, i (i)}
		{#if i > 0}<span class="sep"><ChevronRight size={13} /></span>{/if}
		{#if c.href}
			<a class="crumb" href={c.href} data-sveltekit-keepfocus data-sveltekit-noscroll>{c.label}</a>
		{:else if c.muted}
			<span class="muted">{c.label}</span>
		{:else}
			<span class="current">{c.label}</span>
		{/if}
	{/each}
</div>

<style>
	.crumbs {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 12px 20px 0;
		font-size: 11.5px;
		color: var(--text-dim);
	}
	.crumb {
		/* inline-flex so the label stays vertically centred when the shared mobile
		   tap-target rule (app.css) gives the link a 44px min-height. */
		display: inline-flex;
		align-items: center;
		color: var(--accent-link);
		cursor: pointer;
		background: none;
		border: none;
		padding: 0;
		font: inherit;
		text-decoration: none;
	}
	/* Underlined on hover, not just recoloured: a crumb is a short piece of dim
	   text in a corner, and colour alone left people reading it as a caption rather
	   than as the way to the manufacturer (#989). */
	.crumb:hover {
		color: var(--accent-link-hover);
		text-decoration: underline;
		text-underline-offset: 2px;
	}
	.current {
		color: var(--text-2);
	}
	.muted {
		color: var(--text-dim);
		font-style: italic;
	}
</style>
