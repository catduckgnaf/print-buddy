<script lang="ts">
	/* eslint-disable svelte/no-navigation-without-resolve --
	   Every href below comes from a src/lib/library/params.ts helper, which already
	   resolves against the deploy base path; resolving again would double-apply it. */
	import Swatch from '../Swatch.svelte';
	import ColorEditor from '../ColorEditor.svelte';
	import Button from '../Button.svelte';
	import ConfirmDialog from '../ConfirmDialog.svelte';
	import Plus from '@lucide/svelte/icons/plus';
	import Copy from '@lucide/svelte/icons/copy';
	import Trash2 from '@lucide/svelte/icons/trash-2';
	import Square from '@lucide/svelte/icons/square';
	import SquareCheck from '@lucide/svelte/icons/square-check';
	import EditableField from '../EditableField.svelte';
	import Combobox from '../Combobox.svelte';
	import NumberInput from '../NumberInput.svelte';
	import ProgressBar from '../ProgressBar.svelte';
	import SectionLabel from '../SectionLabel.svelte';
	import ExtraFieldsSection from '../ExtraFieldsSection.svelte';
	import TagsSection from '../TagsSection.svelte';
	import Breadcrumbs from '../Breadcrumbs.svelte';
	import FieldGrid from '../FieldGrid.svelte';
	import Field from '../Field.svelte';
	import VendorSection from './VendorSection.svelte';
	import ChangeVendorModal from './ChangeVendorModal.svelte';
	import OverrideMark from './OverrideMark.svelte';
	import type { Filament, Spool } from '$lib/types';
	import { inventory } from '$lib/stores/inventory.svelte';
	import { settings } from '$lib/stores/settings.svelte';
	import { serverInfo } from '$lib/stores/serverInfo.svelte';
	import { ui } from '$lib/stores/ui.svelte';
	import { page } from '$app/state';
	import * as params from '$lib/library/params';
	import { pct, weightAuto } from '$lib/utils/format';
	import { usageLabel } from '$lib/utils/library';
	import { spoolSource } from '$lib/api/spoolSource';
	import { isAbortError } from '$lib/api/http';
	import { classifyDeleteFailure, planFilamentDelete } from '$lib/library/deletion';
	import { toasts } from '$lib/stores/toasts.svelte';
	import { loadMaterials } from '$lib/data/materials';
	import { live } from '$lib/api/live';
	import { makeSaver, makeExtraSaver } from '$lib/utils/saver';
	import { trackSave } from '$lib/utils/autosave';
	import * as m from '$lib/paraglide/messages';

	let { filament }: { filament: Filament } = $props();

	// Undefined when the filament has no manufacturer set (or it isn't cached yet) —
	// the display falls back to a plain "no manufacturer" note instead of a link.
	let vendor = $derived(inventory.vendorById(filament.vendorId));

	// Empty-spool weight is the one field this filament shares with its
	// manufacturer, whose value seeds a new filament and is then left behind. Mark
	// both ends of the disagreement so the number in force is never ambiguous —
	// same treatment the spool panel gives the fields it shares with a filament.
	let tareShadowsVendor = $derived(
		filament.spoolWeight != null && !!vendor?.emptyWeight && filament.spoolWeight !== vendor.emptyWeight
	);
	let tareOverride = $derived(
		tareShadowsVendor
			? m['inspector.override.overridesManufacturer']({ value: `${vendor!.emptyWeight} g` })
			: undefined
	);
	let vendorTareShadowedBy = $derived(
		tareShadowsVendor ? m['inspector.override.byFilament']({ value: `${filament.spoolWeight} g` }) : undefined
	);

	// Material suggestions for the picker below. Unlike AddSpoolModal we only use the
	// names for autocomplete — editing an existing filament's material must NOT touch
	// its density/diameter/temp fields, so the specs half of the list is ignored here.
	let materialNames = $state<string[]>([]);
	$effect(() => {
		loadMaterials()
			.then(({ names }) => (materialNames = names))
			.catch(() => {});
	});

	// Fetch this filament's spools from the API (scoped list) rather than the cache.
	// Depend on the primitive id (via $derived) — not `filament` itself — so the
	// fetch's own cache upsert (which replaces the `filament` prop object) doesn't
	// re-trigger this effect in an infinite loop.
	let filamentId = $derived(filament.id);
	let spools = $state<Spool[]>([]);
	// Bumped by live spool events so adding/removing/editing a spool refetches
	// this filament's list (the fetch below is server-ordered, not read from the
	// cache, so it needs an explicit nudge to stay in sync).
	let revision = $state(0);
	// Archived spools are hidden by default here, same as in the library list.
	let showArchived = $state(false);
	$effect(() => live.subscribe('spool', {}, () => revision++));
	// Aggregate remaining weight across the currently-listed spools, so the header
	// answers "how much of this filament do I actually have?" (#572, #347, #265).
	// Follows the same `spools` list, so it respects the showArchived toggle for free.
	let totalRemaining = $derived(spools.reduce((sum, s) => sum + (s.remaining ?? 0), 0));
	$effect(() => {
		const id = filamentId;
		const archived = showArchived;
		void revision; // refetch on live spool events
		let cancelled = false;
		spoolSource
			.listSpools({
				filters: {},
				sort: [{ field: 'last_used', dir: 'desc' }],
				groupScope: { field: 'filament', key: id },
				allowArchived: archived,
				limit: 100,
				offset: 0,
				lowThreshold: settings.lowThreshold
			})
			.then((page) => {
				if (!cancelled) spools = page.items;
			})
			.catch((e) => console.error('Failed to load filament spools', e));
		return () => {
			cancelled = true;
		};
	});

	const saver = makeSaver<string, Partial<Filament>>((id, patch) =>
		trackSave(spoolSource.saveFilament(id, patch))
	);
	$effect(() => () => saver.flush());

	function set(patch: Partial<Filament>) {
		inventory.patchFilament(filament.id, patch);
		saver.push(filament.id, patch);
	}

	const extraSaver = makeExtraSaver(
		() => filament.id,
		(id, e) => inventory.patchFilament(id, { extra: e }),
		(id, p) => trackSave(spoolSource.saveFilament(id, { extra: p })),
		() => filament.extra
	);
	$effect(() => () => extraSaver.flush());

	// --- delete -------------------------------------------------------------

	// The API refuses to delete a filament that still has spools, and archiving is
	// no help — it is a flag, not a deletion, so an archived spool holds the
	// filament down just as hard. The list above hides archived spools by default,
	// so ask the server for the real total rather than counting what's on screen.
	// `null` means "not counted yet": the button stays disabled until we know.
	let spoolCount = $state<number | null>(null);
	$effect(() => {
		const id = filamentId;
		void revision; // recount when a spool is added or removed
		const ctrl = new AbortController();
		spoolSource
			.countSpoolsOfFilament(id, ctrl.signal)
			.then((n) => (spoolCount = n))
			.catch((e) => {
				if (!isAbortError(e, ctrl.signal)) console.error('Failed to count filament spools', e);
			});
		return () => ctrl.abort();
	});
	let plan = $derived(planFilamentDelete(spoolCount ?? 0));

	let confirmOpen = $state(false);
	let deleting = $state(false);

	// --- change manufacturer -------------------------------------------------
	// Kept out of the inline-edit path, like the spool's change-filament: the
	// manufacturer is a link to another entity (possibly one that has to be created
	// first), and it carries the empty-spool weight this filament may be inheriting,
	// so it gets a dialog that says what will happen instead of a debounced autosave.
	let changeVendorOpen = $state(false);

	let confirmLines = $derived(
		plan.allowed
			? [m['inspector.delete.filamentBody']({ name: filament.name })]
			: [
					m['inspector.delete.filamentBlocked']({ count: plan.spools, name: filament.name }),
					m['inspector.delete.filamentBlockedHint']()
				]
	);

	async function remove() {
		deleting = true;
		// The edit that is still in flight belongs to a filament that is about to
		// stop existing — dropping it avoids a PATCH that can only 404.
		saver.cancel();
		extraSaver.cancel();
		try {
			await spoolSource.deleteFilament(filament.id);
			toasts.success(m['inspector.delete.filamentDone']());
			params.clearSelection();
		} catch (e) {
			console.error('Failed to delete filament', e);
			const failure = classifyDeleteFailure(e);
			if (failure === 'in-use') {
				// A spool was added between our count and the click.
				toasts.error(m['inspector.delete.errorSpoolsExist']());
				spoolCount = null;
				revision++; // recount, so the dialog tells the truth next time
			} else if (failure === 'gone') {
				toasts.error(m['inspector.delete.errorGone']());
				inventory.removeFilament(filament.id);
				params.clearSelection();
			} else {
				toasts.error(m['inspector.delete.errorUnknown']());
			}
		} finally {
			deleting = false;
			confirmOpen = false;
		}
	}
</script>

<div class="insp">
	<Breadcrumbs
		items={[
			vendor
				? { label: vendor.name, href: params.selectHref(page.url.searchParams, 'vendor', vendor.id) }
				: { label: m['add.noManufacturer'](), muted: true },
			{ label: filament.name }
		]}
	/>

	<div class="head">
		<Swatch colors={filament.colors} direction={filament.multiColorDirection} size={40} radius={9} />
		<div class="titles">
			<div class="title">
				{filament.name}
				<span class="idmono mono">#{filament.id}</span>
				{#if filament.externalId}<span
						class="ext-badge"
						title={serverInfo.externalDbName + ' · ' + filament.externalId}>{serverInfo.externalDbName}</span
					>{/if}
			</div>
			<div class="subtitle">
				{#if vendor}{vendor.name} ·
				{/if}{filament.material} · {filament.diameter} mm
			</div>
		</div>
		<div class="add">
			<Button onclick={() => ui.openAddModal(filament.id)}
				><Plus size={15} /> {m['inspector.addSpoolsOfThis']()}</Button
			>
			<!-- Duplicating and deleting are occasional, so they sit apart as quiet icons
			     and leave the end of the row to the one action this panel is really for.
			     Buying the same filament in another colour is common enough to stay a
			     shortcut here rather than hide behind a menu. Delete stays enabled when
			     spools block it: the dialog then explains why, which a greyed-out button
			     never could. -->
			<span class="sep" aria-hidden="true"></span>
			<Button
				variant="ghost"
				title={m['inspector.duplicateFilament']()}
				ariaLabel={m['inspector.duplicateFilament']()}
				onclick={() => ui.openDuplicateModal(filament.id)}><Copy size={15} /></Button
			>
			<Button
				variant="danger-ghost"
				title={m['inspector.delete.filament']()}
				ariaLabel={m['inspector.delete.filament']()}
				disabled={spoolCount === null || deleting}
				onclick={() => (confirmOpen = true)}><Trash2 size={15} /></Button
			>
		</div>
	</div>

	<ConfirmDialog
		open={confirmOpen}
		busy={deleting}
		title={plan.allowed
			? m['inspector.delete.filamentTitle']()
			: m['inspector.delete.filamentBlockedTitle']()}
		lines={confirmLines}
		confirmLabel={deleting ? m['inspector.delete.deleting']() : m['buttons.delete']()}
		onconfirm={plan.allowed ? remove : undefined}
		onclose={() => (confirmOpen = false)}
	/>

	<ChangeVendorModal
		open={changeVendorOpen}
		{filament}
		current={vendor}
		onclose={() => (changeVendorOpen = false)}
	/>

	<SectionLabel>
		<span style="padding-left:20px"
			>{m['inspector.spoolsCount']({ count: spools.length })}{#if spools.length}<span class="total"
					>{m['inspector.spoolsTotalRemaining']({ weight: weightAuto(totalRemaining) })}</span
				>{/if}</span
		>
		{#snippet right()}
			<button
				class="arch-toggle"
				role="switch"
				aria-checked={showArchived}
				onclick={() => (showArchived = !showArchived)}
			>
				{#if showArchived}<SquareCheck size={14} />{:else}<Square size={14} />{/if}
				{m['buttons.showArchived']()}
			</button>
		{/snippet}
	</SectionLabel>
	<div class="spools">
		{#each spools as s (s.id)}
			<a
				class="spool-row"
				class:archived={s.archived}
				href={params.selectHref(page.url.searchParams, 'spool', String(s.id))}
				data-sveltekit-keepfocus
				data-sveltekit-noscroll
			>
				<span class="id mono">#{s.id}</span>
				<span class="state">{s.archived ? m['spool.fields.archived']() : usageLabel(s)}</span>
				<span class="barwrap">
					<ProgressBar
						value={pct(s.remaining, s.initial)}
						width="100%"
						danger={settings.isLow(s.remaining, s.unused)}
					/>
				</span>
				<span class="rem mono">{weightAuto(s.remaining)}</span>
				<span class="loc">{s.location ?? ''}</span>
			</a>
		{/each}
	</div>

	<div class="grid">
		<div class="col">
			<SectionLabel>{m['inspector.specs']()}</SectionLabel>
			<FieldGrid>
				<Field label={m['filament.fields.name']()}>
					<EditableField value={filament.name} oninput={(v) => set({ name: v })} />
				</Field>
				<Field label={m['filament.fields.material']()}>
					<Combobox
						value={filament.material}
						options={materialNames}
						underline
						oninput={(v) => set({ material: v })}
					/>
				</Field>
				<Field label={m['filament.fields.colorHex']()}>
					{#key filament.id}
						<ColorEditor
							colors={filament.colors}
							direction={filament.multiColorDirection}
							onchange={(v) => set({ colors: v.colors, multiColorDirection: v.direction })}
						/>
					{/key}
				</Field>
				<Field label={m['filament.fields.diameter']()}>
					<NumberInput
						dense
						width="200px"
						unit="mm"
						step={0.05}
						min={0}
						value={filament.diameter}
						onchange={(v) => set({ diameter: v || filament.diameter })}
					/>
				</Field>
				<Field label={m['filament.fields.density']()}>
					<NumberInput
						dense
						width="200px"
						unit="g/cm³"
						step={0.01}
						min={0}
						value={filament.density}
						onchange={(v) => set({ density: v || filament.density })}
					/>
				</Field>
				<Field label={m['filament.fields.weight']()} help={m['filament.fieldsHelp.weight']()}>
					<NumberInput
						dense
						width="200px"
						unit="g"
						step={50}
						min={0}
						value={filament.weight}
						onchange={(v) => set({ weight: v || filament.weight })}
					/>
				</Field>
				<!-- The manufacturer's empty-spool weight is what a new filament of theirs
				     starts from, so name it as the default here and mark the row when this
				     filament has since gone its own way. -->
				<Field label={m['filament.fields.spoolWeight']()} help={m['filament.fieldsHelp.spoolWeight']()}>
					<NumberInput
						dense
						width="200px"
						unit="g"
						step={10}
						min={0}
						placeholder={vendor?.emptyWeight
							? m['inspector.defaultFrom.manufacturer']({ value: String(vendor.emptyWeight) })
							: '—'}
						value={filament.spoolWeight ?? ''}
						onchange={(v) => set({ spoolWeight: v })}
						onclear={() => set({ spoolWeight: undefined })}
					/>
					{#if tareOverride}<OverrideMark label={tareOverride} />{/if}
				</Field>
				<Field label={m['filament.fields.settingsExtruderTemp']()}>
					<NumberInput
						dense
						width="200px"
						unit="°C"
						step={5}
						min={0}
						value={filament.nozzleTemp}
						onchange={(v) => set({ nozzleTemp: Math.round(v) })}
					/>
				</Field>
				<Field label={m['filament.fields.settingsBedTemp']()}>
					<NumberInput
						dense
						width="200px"
						unit="°C"
						step={5}
						min={0}
						value={filament.bedTemp}
						onchange={(v) => set({ bedTemp: Math.round(v) })}
					/>
				</Field>
				<Field label={m['filament.fields.price']()}>
					<NumberInput
						dense
						width="200px"
						unit={settings.currency}
						step={1}
						min={0}
						value={filament.price}
						onchange={(v) => set({ price: v })}
					/>
				</Field>
				<Field label={m['filament.fields.articleNumber']()} help={m['filament.fieldsHelp.articleNumber']()}>
					<EditableField
						value={filament.articleNumber ?? ''}
						mono
						oninput={(v) => set({ articleNumber: v })}
					/>
				</Field>
				{#if filament.externalId}
					<Field label={m['filament.fields.externalId']()} mono>{filament.externalId}</Field>
				{/if}
				<Field label={m['filament.fields.registered']()}>{filament.registeredLabel}</Field>
				<Field label={m['filament.fields.comment']()}>
					<EditableField value={filament.comment} linkify oninput={(v) => set({ comment: v })} />
				</Field>
			</FieldGrid>

			<ExtraFieldsSection entity="filament" extra={filament.extra} onchange={extraSaver.change} manage />

			<TagsSection kind="filament" id={filament.id} tags={filament.tags} />
		</div>

		<div class="col">
			<VendorSection
				{vendor}
				href={vendor ? params.selectHref(page.url.searchParams, 'vendor', vendor.id) : undefined}
				emptyWeightShadowedBy={vendorTareShadowedBy}
				onchange={() => (changeVendorOpen = true)}
			/>
		</div>
	</div>
</div>

<style>
	.head {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 10px 20px 16px;
		border-bottom: 1px solid var(--border-soft);
	}
	.titles {
		min-width: 0;
	}
	.title {
		font-weight: 700;
		font-size: 16px;
	}
	.idmono {
		font-size: 12px;
		color: var(--text-muted);
		font-weight: 400;
	}
	.ext-badge {
		font-size: 10px;
		font-weight: 600;
		vertical-align: middle;
		margin-left: 8px;
		padding: 1px 7px;
		border-radius: 8px;
		background: var(--accent-wash);
		border: 1px solid var(--accent-border);
		color: var(--accent-soft);
		cursor: default;
	}
	.subtitle {
		font-size: 12px;
		color: var(--text-muted);
		margin-top: 2px;
	}
	.add {
		display: flex;
		align-items: center;
		gap: 8px;
		margin-left: auto;
		flex: none;
	}
	.sep {
		width: 1px;
		align-self: stretch;
		margin: 4px 0 4px 2px;
		background: var(--border);
	}
	.spools {
		display: flex;
		flex-direction: column;
		gap: 6px;
		padding: 0 20px;
	}
	.spool-row {
		display: flex;
		align-items: center;
		gap: 9px;
		padding: 9px 12px;
		background: var(--surface-2);
		border: 1px solid var(--swatch-border);
		border-radius: var(--radius-md);
		font-size: 12px;
		cursor: pointer;
		color: inherit;
		font-family: inherit;
		text-align: left;
		text-decoration: none;
	}
	.spool-row:hover {
		border-color: var(--swatch-border-hover);
	}
	.spool-row.archived {
		opacity: 0.6;
	}
	.total {
		margin-left: 10px;
		padding-left: 10px;
		border-left: 1px solid var(--border-soft);
		color: var(--text-muted);
		font-weight: 400;
	}
	.arch-toggle {
		display: inline-flex;
		align-items: center;
		gap: 5px;
		padding: 0 20px 0 0;
		font: inherit;
		font-size: 11.5px;
		background: none;
		border: none;
		color: var(--text-dim);
		cursor: pointer;
	}
	.arch-toggle:hover {
		color: var(--text-2);
	}
	.id {
		color: var(--text-muted);
		width: 36px;
		flex: none;
	}
	.state {
		color: var(--text-2);
		flex: none;
	}
	.barwrap {
		flex: 1;
		min-width: 0;
		display: flex;
	}
	.rem {
		color: var(--text-2);
		flex: none;
	}
	.loc {
		color: var(--text-dim);
		flex: none;
	}
	/* Specs on the left, the manufacturer's own fields on the right — same split as
	   the manufacturer view, which puts its filament list in the second column. */
	.grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 0 32px;
		padding: 4px 20px 24px;
		align-items: start;
	}
	@media (max-width: 620px) {
		.grid {
			grid-template-columns: 1fr;
		}
		/* Keep the header actions reachable on narrow panels by wrapping them onto
		   their own full-width row instead of hiding them. */
		.head {
			flex-wrap: wrap;
		}
		.titles {
			flex: 1;
		}
		.add {
			margin-left: 0;
			flex-basis: 100%;
			flex-wrap: wrap;
		}
	}
</style>
