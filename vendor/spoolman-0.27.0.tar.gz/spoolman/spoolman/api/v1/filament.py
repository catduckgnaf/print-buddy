"""Filament related endpoints."""

import asyncio
import logging
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy.ext.asyncio import AsyncSession

from spoolman.api.v1.models import (
    Filament,
    FilamentEvent,
    Message,
    MultiColorDirection,
    Tag,
    TagConflictMessage,
    extra_fields_request_description,
)
from spoolman.api.v1.tag import TagLinkParameters
from spoolman.database import filament

# Aliased: `tag` is taken by the find endpoint's query parameter, whose name is API surface.
from spoolman.database import tag as tag_db
from spoolman.database.database import get_db_session
from spoolman.database.utils import parse_sort
from spoolman.exceptions import ItemDeleteError, TagConflictError
from spoolman.extra_fields import EntityType, get_extra_fields, validate_extra_field_dict
from spoolman.ws import websocket_manager

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/filament",
    tags=["filament"],
)

# ruff: noqa: D103


class FilamentParameters(BaseModel):
    name: str | None = Field(
        None,
        max_length=64,
        description=(
            "Filament name, to distinguish this filament type among others from the same vendor."
            "Should contain its color for example."
        ),
        examples=["PolyTerra™ Charcoal Black"],
    )
    vendor_id: int | None = Field(None, description="The ID of the vendor of this filament type.")
    material: str | None = Field(
        None,
        max_length=64,
        description="The material of this filament, e.g. PLA.",
        examples=["PLA"],
    )
    price: float | None = Field(
        None,
        ge=0,
        description="The price of this filament in the system configured currency.",
        examples=[20.0],
    )
    density: float = Field(gt=0, description="The density of this filament in g/cm3.", examples=[1.24])
    diameter: float = Field(gt=0, description="The diameter of this filament in mm.", examples=[1.75])
    weight: float | None = Field(
        None,
        gt=0,
        description="The weight of the filament in a full spool, in grams. (net weight)",
        examples=[1000],
    )
    spool_weight: float | None = Field(None, ge=0, description="The empty spool weight, in grams.", examples=[140])
    article_number: str | None = Field(
        None,
        max_length=64,
        description="Vendor article number, e.g. EAN, QR code, etc.",
        examples=["PM70820"],
    )
    comment: str | None = Field(
        None,
        max_length=1024,
        description="Free text comment about this filament type.",
        examples=[""],
    )
    settings_extruder_temp: int | None = Field(
        None,
        ge=0,
        description="Overridden extruder temperature, in °C.",
        examples=[210],
    )
    settings_bed_temp: int | None = Field(
        None,
        ge=0,
        description="Overridden bed temperature, in °C.",
        examples=[60],
    )
    color_hex: str | None = Field(
        None,
        description=(
            "Hexadecimal color code of the filament, e.g. FF0000 for red. Supports alpha channel at the end. "
            "If it's a multi-color filament, the multi_color_hexes field is used instead."
        ),
        examples=["FF0000"],
    )
    multi_color_hexes: str | None = Field(
        None,
        description=(
            "Hexadecimal color code of the filament, e.g. FF0000 for red. Supports alpha channel at the end. "
            "Specifying multiple colors separated by commas. "
            "Also set the multi_color_direction field if you specify multiple colors."
        ),
        examples=["FF0000,00FF00,0000FF"],
    )
    multi_color_direction: MultiColorDirection | None = Field(
        None,
        description=("Type of multi-color filament. Only set if the color_hex field contains multiple colors. "),
        examples=["coaxial", "longitudinal"],
    )
    external_id: str | None = Field(
        None,
        max_length=256,
        description=(
            "Set if this filament comes from an external database. This contains the ID in the external database."
        ),
        examples=["polymaker_pla_polysonicblack_1000_175"],
    )
    extra: dict[str, str | None] | None = Field(
        None,
        description=extra_fields_request_description("filament"),
    )

    @field_validator("color_hex")
    @classmethod
    def color_hex_validator(cls, v: str | None) -> str | None:
        """Validate the color_hex field."""
        if not v:
            return None

        clr = v.upper()
        clr = clr.removeprefix("#")

        for c in clr:
            if c not in "0123456789ABCDEF":
                raise ValueError("Invalid character in color code.")

        if len(clr) not in (6, 8):
            raise ValueError("Color code must be 6 or 8 characters long.")

        return v.removeprefix("#")

    @field_validator("multi_color_hexes")
    @classmethod
    def multi_color_hexes_validator(cls, v: str | None) -> str | None:
        """Validate the multi_color_hexes field."""
        if not v:
            return None
        colors = []
        for clr_raw in v.split(","):
            clr = clr_raw.upper()
            clr = clr.removeprefix("#")

            for c in clr:
                if c not in "0123456789ABCDEF":
                    raise ValueError("Invalid character in color code.")

            if len(clr) not in (6, 8):
                raise ValueError("Color code must be 6 or 8 characters long.")

            colors.append(clr_raw.removeprefix("#"))

        return ",".join(colors)

    @model_validator(mode="after")  # type: ignore[]
    def validate(self) -> "FilamentParameters":
        """Validate the model."""
        if self.color_hex and self.multi_color_hexes:
            raise ValueError("Cannot specify both color_hex and multi_color_hexes.")
        if self.multi_color_hexes and len(self.multi_color_hexes.split(",")) < 2:  # noqa: PLR2004
            raise ValueError("Must specify at least two colors in multi_color_hexes.")
        if self.multi_color_hexes and not self.multi_color_direction:
            raise ValueError("Multi-color filament must have multi_color_direction set.")
        if not self.multi_color_hexes and self.multi_color_direction:
            raise ValueError("Single-color filament must not have multi_color_direction set.")

        return self


class FilamentUpdateParameters(FilamentParameters):
    density: float | None = Field(None, gt=0, description="The density of this filament in g/cm3.", examples=[1.24])
    diameter: float | None = Field(None, gt=0, description="The diameter of this filament in mm.", examples=[1.75])

    @field_validator("density", "diameter")
    @classmethod
    def prevent_none(cls: type["FilamentUpdateParameters"], v: float | None) -> float | None:
        """Prevent density and diameter from being None."""
        if v is None:
            raise ValueError("Value must not be None.")
        return v


@router.get(
    "",
    name="Find filaments",
    description=(
        "Get a list of filaments that matches the search query. "
        "A websocket is served on the same path to listen for updates to any filament, or added or deleted filaments. "
        "See the HTTP Response code 299 for the content of the websocket messages."
    ),
    response_model_exclude_none=True,
    responses={
        200: {"model": list[Filament]},
        299: {"model": FilamentEvent, "description": "Websocket message"},
    },
)
async def find(
    *,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db_session)],
    vendor_name_old: Annotated[
        str | None,
        Query(alias="vendor_name", title="Vendor Name", description="See vendor.name.", deprecated=True),
    ] = None,
    vendor_id_old: Annotated[
        str | None,
        Query(
            alias="vendor_id",
            title="Vendor ID",
            description="See vendor.id.",
            deprecated=True,
            pattern=r"^-?\d+(,-?\d+)*$",
        ),
    ] = None,
    vendor_name: Annotated[
        str | None,
        Query(
            alias="vendor.name",
            title="Vendor Name",
            description=(
                "Partial case-insensitive search term for the filament vendor name. "
                "Separate multiple terms with a comma. Specify an empty string to match filaments with no vendor name. "
                "Surround a term with quotes to search for the exact term."
            ),
        ),
    ] = None,
    vendor_id: Annotated[
        str | None,
        Query(
            alias="vendor.id",
            title="Vendor ID",
            description=(
                "Match an exact vendor ID. Separate multiple IDs with a comma. "
                "Specify -1 to match filaments with no vendor."
            ),
            pattern=r"^-?\d+(,-?\d+)*$",
            examples=["1", "1,2"],
        ),
    ] = None,
    name: Annotated[
        str | None,
        Query(
            title="Filament Name",
            description=(
                "Partial case-insensitive search term for the filament name. Separate multiple terms with a comma. "
                "Specify an empty string to match filaments with no name. "
                "Surround a term with quotes to search for the exact term."
            ),
        ),
    ] = None,
    material: Annotated[
        str | None,
        Query(
            title="Filament Material",
            description=(
                "Partial case-insensitive search term for the filament material. Separate multiple terms with a comma. "
                "Specify an empty string to match filaments with no material. "
                "Surround a term with quotes to search for the exact term."
            ),
        ),
    ] = None,
    article_number: Annotated[
        str | None,
        Query(
            title="Filament Article Number",
            description=(
                "Partial case-insensitive search term for the filament article number. "
                "Separate multiple terms with a comma. "
                "Specify an empty string to match filaments with no article number. "
                "Surround a term with quotes to search for the exact term."
            ),
        ),
    ] = None,
    color_hex: Annotated[
        str | None,
        Query(
            title="Filament Color",
            description="Match filament by similar color.",
        ),
    ] = None,
    color_similarity_threshold: Annotated[
        float,
        Query(
            description=(
                "The similarity threshold for color matching. "
                "A value between 0.0-100.0, where 0 means match only exactly the same color."
            ),
            examples=[20.0],
        ),
    ] = 20.0,
    external_id: Annotated[
        str | None,
        Query(
            description=(
                "Find filaments imported by the given external ID. "
                "Separate multiple IDs with a comma. "
                "Specify empty string to match filaments with no external ID. "
                "Surround a term with quotes to search for the exact term."
            ),
            examples=["polymaker_pla_polysonicblack_1000_175"],
        ),
    ] = None,
    tag: Annotated[
        str | None,
        Query(
            title="Tag UID",
            description=(
                "Match the filament that an NFC/RFID tag with this UID is linked to. Exact match on the "
                "normalized UID: separators are ignored and case does not matter. Only a tag linked to the "
                "filament itself matches, not a tag on one of its spools; look those up on the spool "
                "endpoint. Returns either one filament or none. Returns 400 if the UID is not hexadecimal."
            ),
            examples=["04A2B3C4D5E6F7", "04:a2:b3:c4:d5:e6:f7"],
        ),
    ] = None,
    sort: Annotated[
        str | None,
        Query(
            title="Sort",
            description=(
                'Sort the results by the given field. Should be a comma-separate string with "field:direction" items.'
            ),
            examples=["vendor.name:asc,spool_weight:desc"],
        ),
    ] = None,
    limit: Annotated[
        int | None,
        Query(title="Limit", description="Maximum number of items in the response."),
    ] = None,
    offset: Annotated[int, Query(title="Offset", description="Offset in the full result set if a limit is set.")] = 0,
) -> JSONResponse:
    try:
        sort_by = parse_sort(sort)
    except ValueError as e:
        return JSONResponse(status_code=400, content=Message(message=str(e)).dict())

    vendor_id = vendor_id if vendor_id is not None else vendor_id_old
    if vendor_id is not None:
        vendor_ids = [int(vendor_id_item) for vendor_id_item in vendor_id.split(",")]
    else:
        vendor_ids = None

    if color_hex is not None:
        filter_by_ids = await filament.find_by_color(
            db=db,
            color_query_hex=color_hex,
            similarity_threshold=color_similarity_threshold,
        )
    else:
        filter_by_ids = None

    # Extract custom field filters from query parameters
    extra_field_filters = {}
    query_params = request.query_params
    for key, value in query_params.items():
        if key.startswith("extra."):
            field_key = key[6:]  # Remove "extra." prefix
            extra_field_filters[field_key] = value

    try:
        db_items, total_count = await filament.find(
            db=db,
            ids=filter_by_ids,
            vendor_name=vendor_name if vendor_name is not None else vendor_name_old,
            vendor_id=vendor_ids,
            name=name,
            material=material,
            article_number=article_number,
            external_id=external_id,
            tag=tag,
            extra_field_filters=extra_field_filters if extra_field_filters else None,
            sort_by=sort_by,
            limit=limit,
            offset=offset,
        )
    except ValueError as e:
        return JSONResponse(status_code=400, content=Message(message=str(e)).dict())

    # Set x-total-count header for pagination
    return JSONResponse(
        content=jsonable_encoder(
            (Filament.from_db(db_item) for db_item in db_items),
            exclude_none=True,
        ),
        headers={"x-total-count": str(total_count)},
    )


@router.websocket(
    "",
    name="Listen to filament changes",
)
async def notify_any(
    websocket: WebSocket,
) -> None:
    await websocket.accept()
    websocket_manager.connect(("filament",), websocket)
    try:
        while True:
            await asyncio.sleep(0.5)
            if await websocket.receive_text():
                await websocket.send_json({"status": "healthy"})
    except WebSocketDisconnect:
        websocket_manager.disconnect(("filament",), websocket)


@router.get(
    "/{filament_id}",
    name="Get filament",
    description=(
        "Get a specific filament. A websocket is served on the same path to listen for changes to the filament. "
        "See the HTTP Response code 299 for the content of the websocket messages."
    ),
    response_model_exclude_none=True,
    responses={404: {"model": Message}, 299: {"model": FilamentEvent, "description": "Websocket message"}},
)
async def get(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    filament_id: int,
) -> Filament:
    db_item = await filament.get_by_id(db, filament_id)
    return Filament.from_db(db_item)


@router.websocket(
    "/{filament_id}",
    name="Listen to filament changes",
)
async def notify(
    websocket: WebSocket,
    filament_id: int,
) -> None:
    await websocket.accept()
    websocket_manager.connect(("filament", str(filament_id)), websocket)
    try:
        while True:
            await asyncio.sleep(0.5)
            if await websocket.receive_text():
                await websocket.send_json({"status": "healthy"})
    except WebSocketDisconnect:
        websocket_manager.disconnect(("filament", str(filament_id)), websocket)


@router.post(
    "",
    name="Add filament",
    description="Add a new filament to the database.",
    response_model_exclude_none=True,
    response_model=Filament,
    responses={400: {"model": Message}},
)
async def create(  # noqa: ANN201
    db: Annotated[AsyncSession, Depends(get_db_session)],
    body: FilamentParameters,
):
    if body.extra:
        all_fields = await get_extra_fields(db, EntityType.filament)
        try:
            validate_extra_field_dict(all_fields, body.extra)
        except ValueError as e:
            return JSONResponse(status_code=400, content=Message(message=str(e)).dict())

    db_item = await filament.create(
        db=db,
        density=body.density,
        diameter=body.diameter,
        name=body.name,
        vendor_id=body.vendor_id,
        material=body.material,
        price=body.price,
        weight=body.weight,
        spool_weight=body.spool_weight,
        article_number=body.article_number,
        comment=body.comment,
        settings_extruder_temp=body.settings_extruder_temp,
        settings_bed_temp=body.settings_bed_temp,
        color_hex=body.color_hex,
        multi_color_hexes=body.multi_color_hexes,
        multi_color_direction=body.multi_color_direction,
        external_id=body.external_id,
        extra=body.extra,
    )

    return Filament.from_db(db_item)


@router.patch(
    "/{filament_id}",
    name="Update filament",
    description=(
        "Update any attribute of a filament. Only fields specified in the request will be affected. "
        "If extra is set, all existing extra fields will be removed and replaced with the new ones."
    ),
    response_model_exclude_none=True,
    response_model=Filament,
    responses={
        400: {"model": Message},
        404: {"model": Message},
    },
)
async def update(  # noqa: ANN201
    db: Annotated[AsyncSession, Depends(get_db_session)],
    filament_id: int,
    body: FilamentUpdateParameters,
):
    patch_data = body.model_dump(exclude_unset=True)

    if body.extra:
        all_fields = await get_extra_fields(db, EntityType.filament)
        try:
            validate_extra_field_dict(all_fields, body.extra)
        except ValueError as e:
            return JSONResponse(status_code=400, content=Message(message=str(e)).dict())

    db_item = await filament.update(
        db=db,
        filament_id=filament_id,
        data=patch_data,
    )

    return Filament.from_db(db_item)


@router.delete(
    "/{filament_id}",
    name="Delete filament",
    description="Delete a filament.",
    response_model=Message,
    responses={
        403: {"model": Message},
        404: {"model": Message},
    },
)
async def delete(  # noqa: ANN201
    db: Annotated[AsyncSession, Depends(get_db_session)],
    filament_id: int,
):
    try:
        await filament.delete(db, filament_id)
    except ItemDeleteError:
        logger.exception("Failed to delete filament.")
        return JSONResponse(
            status_code=403,
            content={"message": "Failed to delete filament, see server logs for more information."},
        )
    return Message(message="Success!")


@router.post(
    "/{filament_id}/tag",
    name="Link a tag to a filament",
    description=(
        "Link a physical NFC/RFID tag to this filament type, so that the tag's UID identifies it. "
        "A tag identifies exactly one spool or filament; linking a UID that something else already "
        "holds returns 409 with the holder's id, so a client can offer to move it instead. "
        "Re-linking a tag to the filament that already holds it succeeds and changes nothing, "
        "except that a format sent now refines one recorded earlier."
    ),
    status_code=201,
    response_model_exclude_none=True,
    response_model=Tag,
    responses={
        400: {"model": Message},
        404: {"model": Message},
        409: {"model": TagConflictMessage},
    },
)
async def link_tag(  # noqa: ANN201
    db: Annotated[AsyncSession, Depends(get_db_session)],
    filament_id: int,
    body: TagLinkParameters,
):
    try:
        db_item = await tag_db.link_filament(db=db, filament_id=filament_id, uid=body.uid, tag_format=body.format)
    except ValueError as e:
        return JSONResponse(status_code=400, content=Message(message=str(e)).dict())
    except TagConflictError as e:
        return JSONResponse(
            status_code=409,
            content=TagConflictMessage(message=str(e), spool_id=e.spool_id, filament_id=e.filament_id).dict(),
        )
    return Tag.from_db(db_item)


@router.delete(
    "/{filament_id}/tag/{uid}",
    name="Unlink a tag from a filament",
    description=(
        "Unlink a physical NFC/RFID tag from this filament. The UID is matched the same way it is "
        "stored: separators are ignored and case does not matter. Deleting a filament unlinks its "
        "tags on its own, so this is only for taking one tag off a filament that keeps existing."
    ),
    status_code=204,
    responses={400: {"model": Message}, 404: {"model": Message}},
)
async def unlink_tag(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    filament_id: int,
    uid: Annotated[
        str,
        Path(
            title="Tag UID",
            description="The tag's UID, in any shape. Normalized before matching.",
            examples=["04A2B3C4D5E6F7"],
        ),
    ],
) -> Response:
    try:
        await tag_db.unlink_filament(db=db, filament_id=filament_id, uid=uid)
    except ValueError as e:
        return JSONResponse(status_code=400, content=Message(message=str(e)).dict())
    return Response(status_code=204)
