"""Shared extra-field definitions and settings access."""

from __future__ import annotations

import json
import logging
from enum import Enum
from typing import TYPE_CHECKING

from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from pydantic import ValidationError as PydanticValidationError

from spoolman.database import setting as db_setting
from spoolman.exceptions import ItemNotFoundError
from spoolman.settings import parse_setting

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


class EntityType(Enum):
    vendor = "vendor"
    filament = "filament"
    spool = "spool"


class ExtraFieldType(Enum):
    text = "text"
    integer = "integer"
    integer_range = "integer_range"
    float = "float"
    float_range = "float_range"
    datetime = "datetime"
    boolean = "boolean"
    choice = "choice"


class ExtraFieldParameters(BaseModel):
    name: str = Field(description="Nice name", min_length=1, max_length=128)
    order: int = Field(0, description="Order of the field")
    unit: str | None = Field(None, description="Unit of the value", min_length=1, max_length=16)
    field_type: ExtraFieldType = Field(description="Type of the field")
    default_value: str | None = Field(None, description="Default value of the field")
    choices: list[str] | None = Field(
        None,
        description="Choices for the field, only for field type choice",
        min_length=1,
    )
    multi_choice: bool | None = Field(None, description="Whether multiple choices can be selected")


class ExtraField(ExtraFieldParameters):
    key: str = Field(description="Unique key", pattern="^[a-z0-9_]+$", min_length=1, max_length=64)
    entity_type: EntityType = Field(description="Entity type this field is for")


# Matches the settings cap in spoolman/database/setting.py. The columns are Text(), so nothing
# stopped a single request storing megabytes: unbounded database growth, and the resulting
# websocket event overflowed the 1 MiB default frame limit, killing live updates for every client.
EXTRA_FIELD_VALUE_MAX_LENGTH = 2**16 - 1

# Extra fields are a per-entity schema, not a data store. A few dozen is already generous, and a
# bound keeps the registry -- which is cached in memory and embedded in every entity response --
# from being grown without limit.
MAX_EXTRA_FIELDS_PER_ENTITY = 128


def validate_extra_field_value(field: ExtraFieldParameters, value: str) -> None:  # noqa: C901, PLR0912, PLR0915
    """Validate that the value has the correct type."""
    if len(value) > EXTRA_FIELD_VALUE_MAX_LENGTH:
        raise ValueError(
            f"Value is too big, max size is {EXTRA_FIELD_VALUE_MAX_LENGTH} characters.",
        )

    try:
        data = json.loads(value)
    except json.JSONDecodeError:
        raise ValueError("Value is not valid JSON.") from None

    if field.field_type == ExtraFieldType.text:
        if not isinstance(data, str):
            raise ValueError("Value is not a string.")
    elif field.field_type == ExtraFieldType.integer:
        if not isinstance(data, int):
            raise ValueError("Value is not an integer.")
    elif field.field_type == ExtraFieldType.integer_range:
        if not isinstance(data, list):
            raise ValueError("Value is not a list.")
        if len(data) != 2:  # noqa: PLR2004
            raise ValueError("Value list must have exactly two values.")
        if not all(isinstance(item, int) or item is None for item in data):
            raise ValueError("Value list must contain only integers or null.")
    elif field.field_type == ExtraFieldType.float:
        if not isinstance(data, (float, int)) or isinstance(data, bool):
            raise ValueError("Value is not a float.")
    elif field.field_type == ExtraFieldType.float_range:
        if not isinstance(data, list):
            raise ValueError("Value is not a list.")
        if len(data) != 2:  # noqa: PLR2004
            raise ValueError("Value list must have exactly two values.")
        if not all((isinstance(item, (float, int)) or item is None) and not isinstance(item, bool) for item in data):
            raise ValueError("Value list must contain only floats or null.")
    elif field.field_type == ExtraFieldType.datetime:
        if not isinstance(data, str):
            raise ValueError("Value is not a string.")
    elif field.field_type == ExtraFieldType.boolean:
        if not isinstance(data, bool):
            raise ValueError("Value is not a boolean.")
    elif field.field_type == ExtraFieldType.choice:
        if field.multi_choice:
            if not isinstance(data, list):
                raise ValueError("Value is not a list.")
            if not all(isinstance(item, str) for item in data):
                raise ValueError("Value list must contain only strings.")
            if field.choices is not None and not all(item in field.choices for item in data):
                raise ValueError("Value list contains invalid choices.")
        else:
            if not isinstance(data, str):
                raise ValueError("Value is not a string.")
            if field.choices is not None and data not in field.choices:
                raise ValueError("Value is not a valid choice.")
    else:
        raise ValueError(f"Unknown field type {field.field_type}.")


def validate_extra_field(field: ExtraFieldParameters) -> None:
    """Validate an extra field."""
    if field.field_type == ExtraFieldType.choice:
        if field.choices is None:
            raise ValueError("Choices must be set for field type choice.")
        if field.multi_choice is None:
            raise ValueError("Multi choice must be set for field type choice.")
    else:
        if field.choices is not None:
            raise ValueError("Choices must not be set for field type other than choice.")
        if field.multi_choice is not None:
            raise ValueError("Multi choice must not be set for field type other than choice.")

    if field.default_value is not None:
        try:
            validate_extra_field_value(field, field.default_value)
        except ValueError as e:
            raise ValueError(f"Default value is not valid: {e}") from None


def validate_extra_field_dict(all_fields: list[ExtraField], fields_input: dict[str, str | None]) -> None:
    """Validate a dict of extra fields.

    A null value means "this entity has no value for the field" — it is stored as no row at
    all, so it is the way to clear a value that has been set. It is valid for every field
    type, so there is nothing to check for those keys.
    """
    all_field_lookup = {field.key: field for field in all_fields}
    for key, value in fields_input.items():
        if key not in all_field_lookup:
            raise ValueError(f"Unknown extra field {key}.")
        if value is None:
            continue
        field = all_field_lookup[key]
        try:
            validate_extra_field_value(field, value)
        except ValueError as e:
            raise ValueError(f"Invalid extra field for key {key}: {e!s}") from None


extra_field_cache: dict[EntityType, list[ExtraField]] = {}

# Settings named extra_fields_<entity> hold the serialized registry for that entity type.
_EXTRA_FIELDS_SETTING_PREFIX = "extra_fields_"


def entity_type_of_setting(key: str) -> EntityType | None:
    """Get the entity type whose extra fields a setting key holds, if it holds any.

    Args:
        key: A setting key, e.g. ``extra_fields_spool``.

    Returns:
        Optional[EntityType]: The entity type, or None if this is not an extra-fields setting.

    """
    if not key.startswith(_EXTRA_FIELDS_SETTING_PREFIX):
        return None
    try:
        return EntityType(key.removeprefix(_EXTRA_FIELDS_SETTING_PREFIX))
    except ValueError:
        return None


def validate_extra_field_setting(key: str, value: str) -> None:
    """Validate the serialized extra-field registry written to an ``extra_fields_*`` setting.

    The /field endpoints validate what they write, but the generic settings endpoint did not, so a
    malformed array written through it would be accepted and then fail to parse on every later
    read -- leaving GET /field/{entity} permanently returning 500.

    Does nothing for any other setting key.

    Args:
        key: The setting key being written.
        value: The JSON-encoded setting value.

    Raises:
        ValueError: If the value is not a valid list of extra fields.

    """
    entity_type = entity_type_of_setting(key)
    if entity_type is None:
        return

    fields = json.loads(value)
    if not isinstance(fields, list):
        # ValueError, not TypeError: this is a validation failure the caller turns into a 400.
        raise ValueError(f"Setting {key} must be an array of extra fields.")  # noqa: TRY004

    if len(fields) > MAX_EXTRA_FIELDS_PER_ENTITY:
        raise ValueError(
            f"Setting {key} has {len(fields)} extra fields, the maximum is {MAX_EXTRA_FIELDS_PER_ENTITY}.",
        )

    for index, obj in enumerate(fields):
        try:
            field = ExtraField.model_validate(obj)
        except PydanticValidationError as e:
            raise ValueError(f"Extra field at index {index} is not valid: {e.error_count()} errors. {e}") from None
        if field.entity_type != entity_type:
            raise ValueError(
                f"Extra field at index {index} has entity type {field.entity_type.value!r}, expected "
                f"{entity_type.value!r}.",
            )
        try:
            validate_extra_field(field)
        except ValueError as e:
            raise ValueError(f"Extra field at index {index} is not valid: {e}") from None

    keys = [field["key"] for field in fields if isinstance(field, dict) and "key" in field]
    if len(set(keys)) != len(keys):
        raise ValueError(f"Setting {key} contains duplicate extra field keys.")


def invalidate_extra_field_cache(key: str) -> None:
    """Drop the cached extra fields for the entity type a setting key belongs to.

    Does nothing for any other setting key.

    Args:
        key: The setting key that was written.

    """
    entity_type = entity_type_of_setting(key)
    if entity_type is not None:
        extra_field_cache.pop(entity_type, None)
        logger.info("Extra field cache for entity type %s invalidated.", entity_type.name)


async def get_extra_fields(db: AsyncSession, entity_type: EntityType) -> list[ExtraField]:
    """Get all extra fields for a specific entity type."""
    if entity_type in extra_field_cache:
        return extra_field_cache[entity_type]

    setting_def = parse_setting(f"extra_fields_{entity_type.name}")
    try:
        setting = await db_setting.get(db, setting_def)
        setting_value = setting.value
    except ItemNotFoundError:
        setting_value = setting_def.default

    setting_array = json.loads(setting_value)
    if not isinstance(setting_array, list):
        logger.warning("Setting %s is not a list, using default.", setting_def.key)
        setting_array = []

    fields = [ExtraField.parse_obj(obj) for obj in setting_array]
    extra_field_cache[entity_type] = fields
    return fields


async def add_or_update_extra_field(db: AsyncSession, entity_type: EntityType, extra_field: ExtraField) -> None:
    """Add or update an extra field for a specific entity type."""
    validate_extra_field(extra_field)

    extra_fields = await get_extra_fields(db, entity_type)
    existing_field = next((field for field in extra_fields if field.key == extra_field.key), None)
    if existing_field is not None:
        if existing_field.field_type != extra_field.field_type:
            raise ValueError("Field type cannot be changed.")
        if extra_field.field_type == ExtraFieldType.choice:
            if existing_field.multi_choice != extra_field.multi_choice:
                raise ValueError("Multi choice cannot be changed.")
            if (
                existing_field.choices is not None
                and extra_field.choices is not None
                and not all(choice in extra_field.choices for choice in existing_field.choices)
            ):
                raise ValueError("Cannot remove existing choices.")

    extra_fields = [field for field in extra_fields if field.key != extra_field.key]
    if len(extra_fields) >= MAX_EXTRA_FIELDS_PER_ENTITY:
        raise ValueError(
            f"Cannot add another extra field for {entity_type.name}, the maximum is {MAX_EXTRA_FIELDS_PER_ENTITY}.",
        )
    extra_fields.append(extra_field)

    setting_def = parse_setting(f"extra_fields_{entity_type.name}")
    await db_setting.update(db=db, definition=setting_def, value=json.dumps(jsonable_encoder(extra_fields)))

    extra_field_cache[entity_type] = extra_fields
    logger.info("Added/updated extra field %s for entity type %s.", extra_field.key, entity_type.name)
